import { createContext, useState } from "react";

const AppContext = createContext();

/* [
    {
        id: 1,
        title: "todo",
        cards: [{
            title: "aksjdh",
            description: ""
        }]
    },
    {
        id: 2,
        title: "todo2",
        cards: []
    },
    {
        id: 3,
        title: "todo3",
        cards: []
    }
]

*/


export {AppContext};