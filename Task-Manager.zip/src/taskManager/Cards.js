import Card from "./Card"

export default function Cards({cards=[], deleteCard, task, updateCard}){
    return (<div className="cards">
       {cards.map(card=>{
        return <Card key={card.id} card={card} deleteCard={deleteCard} task={task} updateCard={updateCard} />
       })}
    </div>)
}