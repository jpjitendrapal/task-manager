import {useEffect, useRef, useState} from 'react';
export default function Card({card, deleteCard, task, updateCard}){
    const [editing, setEditing] = useState(false);
    const [editingDesc, setEditingDesc] = useState(false);

    const titleRef = useRef();
    const descRef = useRef();

    const changeHandler = (ev)=>{
        updateCard(task.id,card.id, ev.target.value, card.description);
        setEditing(false);
    }
    const changeDescHandler = (ev)=>{
        updateCard(task.id,card.id, card.title , ev.target.value);
        setEditingDesc(false);
    }

    const drag = (ev)=>{
        ev.dataTransfer.setData('dragCard', JSON.stringify({card: card, taskId: task.id}));
    }
    const titleClickHandler = ()=>{
        setEditing(true);
    }
    const descClickHandler = ()=>{
        setEditingDesc(true);
    } 
    useEffect(()=>{
        if(editing && titleRef.current){
            titleRef.current.focus();
        }
    },[editing, titleRef.current])

    useEffect(()=>{
        if(editingDesc && descRef.current){
            descRef.current.focus();
        }
    },[editingDesc, descRef.current])

    return (<div className="card" draggable={true} onDragStart={drag}>
        <div className="cross" onClick={()=> {deleteCard(task.id, card.id)}}>X</div>
        
        {editing ? 
        <div className="title">
            <input ref={titleRef} type="text" placeholder="add card title" onBlur={changeHandler} onFocus={(e)=>{e.target.value = card.title}} />
        </div>
        :
        <div className="title" onClick={titleClickHandler}>{card.title}</div>
        }

        {editingDesc ? 
        <div className="desc">
            <textarea ref={titleRef} type="text" placeholder="add card description" onBlur={changeDescHandler} onFocus={(e)=>{e.target.value = card.description}} />
        </div>
        :
        <div className="desc" onClick={descClickHandler}>{card.description}</div>
        }
    </div>)
}